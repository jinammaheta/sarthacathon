package com.example.smcjinam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText e1,e2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void doLog(View v) {
        e1 = (EditText) findViewById(R.id.user_name);
        e2 = (EditText) findViewById(R.id.login_password);
        final String s1, s2;
        s1 = e1.getText().toString();
        s2 = e2.getText().toString();
        final String finalS = s1;
        BackgroundTask bt = new BackgroundTask(this, new response() {
            @Override
            public void onProgressFinish(String res, Context c) {
                if(!res.equals("NO User Found")) {

                    SharedPreferences sd = getSharedPreferences("session", 0);
                    SharedPreferences.Editor ed = sd.edit();
                    ed.putString("operatorname", s1);
                    ed.putString("area", res);
                    ed.commit();
                    startActivity(new Intent(c, AddRemove.class));
                }
                else
                {
                    Toast.makeText(c, res, Toast.LENGTH_SHORT).show();
                }


            }
        });
        bt.execute("Login", s1, s2);
    }
}
