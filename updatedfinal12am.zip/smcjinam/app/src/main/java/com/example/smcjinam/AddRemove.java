package com.example.smcjinam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

public class AddRemove extends AppCompatActivity {

    TextView t1;
    TextInputLayout t2,t3,t4;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_remove);
        t1=(TextView)findViewById(R.id.t1);
        final int[] slots = new int[1];
        BackgroundTask bt = new BackgroundTask(this, new response() {
            @Override
            public void onProgressFinish(String res, Context c) {
                t1.setText("Available slots are: "+res);
                if(Integer.parseInt(res)<=0)
                {

                    b1=(Button)findViewById(R.id.add);
                    b1.setClickable(false);

                }
                if(Integer.parseInt(res)>=60)
                {
                    b1=(Button)findViewById(R.id.remove);
                    b1.setClickable(false);
                }

            }
        });

        bt.execute("fetchdata", getSharedPreferences("session",0).getString("area",null));


    }
    public void doADD(View v)
    {
        startActivity(new Intent(this,Addentry.class));

    }
    public void doREMOVE(View v)
    {
        startActivity(new Intent(this,Removeentry.class));
    }

}