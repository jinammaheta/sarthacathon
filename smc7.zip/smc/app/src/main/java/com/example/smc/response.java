package com.example.smc;

import android.content.Context;

public interface response {
    public void onProgressFinish(String res, Context c);
}
