package com.example.smc;

import java.util.Comparator;

class GridDataSortingComparator implements Comparator<GridItem> {
    @Override
    public int compare(GridItem t1, GridItem t2) {
        int compareduration = t1.getDuration()
                .compareTo(t2.getDuration());
        int comparedistance = t1.getDistance()
                .compareTo(t2.getDistance());
        if (compareduration == 0) {
            return comparedistance;
        } else {
            return compareduration;
        }
    }
}
